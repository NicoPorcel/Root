#ifndef UTILES_H_INCLUDED
#define UTILES_H_INCLUDED

#include <iostream>
#include "constantes.h"

/*PRE: -
  POS: devuelve 'true' si la linea posee al menos un guion, 'false' de lo contrario
*/
bool tieneGuion(string linea);

/*PRE: -
  POS: si la linea tiene guines, se los reemplaza por un espacio
*/
void quitarGuion(string &linea);

/*PRE: -
  POS: limpia la consola
*/
void limpiarConsola();

/*PRE: -
  POS: pausa la consola
*/
void pausarConsola();

/*PRE: -
  POS: pausa la consola y luego la limpia
*/
void pausarLimpiar();

#endif