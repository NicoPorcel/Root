#include "utiles.h"

bool tieneGuion(string linea) {
    bool hayGuion = false;
    
    int i = 0;
    while (linea[i] && !hayGuion){
        if(linea[i] == GUION) hayGuion = true;
        i++;
    }
    
    return hayGuion;
}

void quitarGuion(string &linea) {
    int i = 0;
    while (linea[i]){
        if(linea[i] == GUION) linea[i] = ESPACIO;
        i++;
    }
    
}

void limpiarConsola() {
    system("cls");
}

void pausarConsola() { 
    system("pause");
}

void pausarLimpiar() {
    pausarConsola();
    limpiarConsola();
}