#ifndef CONSTANTES_H_INCLUDED
#define CONSTANTES_H_INCLUDED

#include <string>
using namespace std;

// --- RUTA DE LOS ARCHIVOS ---
const string RUTA_EQUIPOS = "equipos.txt";
const string RUTA_RESULTADOS = "resultados.csv";

//SEPARADORES
const char GUION = '_';
const char ESPACIO = ' ';
const char COMA = ',';
const string MENOS = "-";

//CANTIDAD MAXIMA PARA DEFINIR MI VECTOR DINAMICO
const int MAX_EQUIPOS = 10;

//PUNTOS POR PARTIDO
const int VICTORIA = 3;
const int EMPATE = 1;
const int VICTORIA_POR_PENAL = 2;
const int DERROTA_POR_PENAL = 1;

//OPCIONES DEL MENU
const int CANT_OPCIONES = 5;
const int LISTAR_EQUIPOS = 1;
const int MOSTRAR_PODIO = 2;
const int BUSCAR_POR_NOMBRE = 3;
const int MOSTRAR_POR_FASES = 4;
const int SALIR = 5;

const string VEC_MENU[CANT_OPCIONES] = {"1", "2", "3", "4", "5"};

//FASES
const int CANT_FASES = 6;

enum FASES {GRUPOS, OCTAVOS, CUARTOS, SEMIS, TERCER_PUESTO, FINAL};

const string VEC_FASES[CANT_FASES] = {"grupos", "octavos", "cuartos", "semifinales", "tercer puesto", "final"};

//MARCADOR DE UN PARTIDO
typedef struct {
    string equipo1, equipo2;
    string golesEquipo1, golesEquipo2;
    string penalesEquipo1, penalesEquipo2;
} Marcador;

//PODIO
const int TAMANIO_PODIO = 3;
const int PRIMERO = 0;
const int SEGUNDO = 1;
const int TERCERO = 2;

//LETRAS PARA COMPARAR CARACTER A CARACT.
const char VEC_LETRAS[52] = {'A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j'
,'K','k','L','l','M','m','N','n','O','o','P','p','Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z'};

const string VEC_NUMEROS_STR[11] = {"-1", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

#endif