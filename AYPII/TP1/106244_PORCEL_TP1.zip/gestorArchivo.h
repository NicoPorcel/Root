#ifndef GESTORARCHIVO_H_INCLUDED
#define GESTORARCHIVO_H_INCLUDED

#include "utiles.h"
#include "Laebb.h"
#include <fstream>


/*PRE: recibe un puntero a un vector dinamico con memoria ya reservada, y una ruta de archivo.
  POS: procesa el archivo guardando su informacion en el vector dinamico.
*/
void procesarEquipos(Laebb* laebb, string ruta_archivo);

/*PRE: recibe un puntero a un vector dinamico con memoria ya reservada, y una ruta de archivo.
  POS: procesa el archivo guardando su informacion en el vector dinamico.
*/
void procesarResultados(Laebb* laebb, string ruta_archivo);

/*PRE: -
  POS: guarda el nombre del equipo y el grupo, en un puntero Equipo, el cual se guarda en el vector dinamico.
*/
void procesarLineaEquipos(string linea, Laebb* laebb);

/*PRE: recibe un puntero a vector dinamico con memoria reservada, un string no vacio, 
      y un entero que representa la fase (ver FASES en 'constantes.h')
  POS: procesa los datos de la linea y los guarda en el vector dinamico
*/
void procesarDatosDeFase(Laebb* laebb, string linea, int fase);

/*PRE: recibe un puntero a vector dinamico con equipos cargados, un entero que representa la fase
      y un marcador con los datos del partido cargados
  POS: guarda en el vector los puntos que correspondan a cada equipo
*/
void guardarResultado(Laebb* laebb, int fase, Marcador marcador);

/*PRE: -
  POS: devuelve un numero entre 0 y 5 que representa cada una de las Fases (ver FASES en 'constantes.h')
*/
int obtenerFase(string linea);

/*PRE: -
  POS: devuelve 'true' si la linea representa el nombre de una fase, 'false' de lo contrario
*/
bool esUnaFase(string linea);

/*PRE: -
  POS: se devuelve una cadena con el nombre de un pais y se modifica el valor de 'i' para continuar leyendo la linea
*/
string obtenerNombreDeEquipo(string linea, size_t &i);

/*PRE: -
  POS: se devuelve una cadena con la cantidad de penales y se modifica el valor de 'i' para continuar leyendo la linea 
*/
string obtenerPenales(string linea, size_t &i);

#endif