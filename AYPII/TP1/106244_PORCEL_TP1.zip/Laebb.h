#ifndef LAEBB_H_INCLUDED
#define LAEBB_H_INCLUDED

#include <iostream>
#include "constantes.h"

typedef struct {
  string nombre;
  char grupo;
  int puntosDeFase[CANT_FASES] = {0, 0, 0, 0, 0, 0};
  int puntosTotales = 0;
  int faseAlcanzada;
} Equipo;

typedef struct {
  Equipo** equipos = nullptr;
  size_t tamanio = 0;
  size_t max = MAX_EQUIPOS;
} Laebb;

/*PRE: -
  POS: devuelve un puntero Equipo con nombre y grupo asignados
*/
Equipo* generarEquipo(string nombre, char grupo);

/*PRE: recibe un puntero a vector dinamico y un puntero a un Equipo ambos con memoria ya reservada
  POS: agrega el Equipo al vector dinamico, ordenando el vector (por nombres) con metodo de insercion
*/
void agregarEquipo(Laebb* laebb, Equipo* equipo);

/*PRE: -
  POS: aumenta el maximo tamanio del vector en 1
*/
void pedirMemoria(Laebb* laebb);

/*PRE: -
  POS: devuelve 'true' si cadena1 > cadena2, 'false' de lo contrario 
*/
bool esMayor(string cadena1, string cadena2);

/*PRE: recibe un puntero a vector dinamico con equipos cargados y el nombre de algun equipo
  POS: devuelve un puntero al Equipo con el nombre ingresado 
*/
Equipo* obtenerEquipo(Laebb* laebb, string nombre);

/*PRE: 0 <= fase <= 5 (ver 'FASES' en 'constantes.h')
  POS: ordena los equipos por los puntos que hayan conseguido en la fase 
*/
void ordenarPorPuntosDeFase(Laebb* laebb, int fase);

/*PRE: -
  POS: ordena los equipos por grupos
*/
void ordenarPorGrupos(Laebb* laebb);

/*PRE: - 
  POS: libera la memoria que se haya reservado
*/
void liberarMemoria(Laebb* laebb);

#endif