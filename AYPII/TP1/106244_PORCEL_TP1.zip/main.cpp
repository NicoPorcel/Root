#include <iostream>
#include "gestorArchivo.h"
#include "funciones.h"
#include <string>

int main() {

    Laebb* laebb = nullptr;
    laebb = new Laebb;

    procesarEquipos(laebb, RUTA_EQUIPOS);
    procesarResultados(laebb, RUTA_RESULTADOS);
    
    if(laebb->equipos)
        menu(laebb);
    else liberarMemoria(laebb);
    
    return 0;
}