#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#include "constantes.h"
#include "utiles.h"
#include "Laebb.h"

/*PRE: recibe un puntero a un vector dinamico con datos almacenados
  POS: muestra un menu y procesa la opcion ingresada por el usuario
*/
void menu(Laebb* laebb);

/*PRE: -
  POS: muestra un saludo
*/
void saludar();

/*PRE: -
  POS: muestra las opciones del menu
*/
void mostrarMenu();

/*PRE: -
  POS: devuelve 'true' si "1" <= opcion <= "5", 'false' de lo contrario
*/ 
bool opcionValida(string opcion);

/*PRE: -
  POS: lista los equipos, mostrando su nombre y grupo al que pertenece
*/
void listarEquipos(Laebb* laebb);

/*PRE: -
  POS: lista los 3 primeros lugares del campeonato
*/
void mostrarPodio(Laebb* laebb);

/*PRE: -
  POS: busca un equipo por nombre ingresado por el usuario, muestra sus datos si este se encuentra,
  sino se informa que no se encontro
*/
void buscarEquipoPorNombre(Laebb* laebb);

/*PRE: -
  POS: se muestra cada fase y los equipos ordenados por los puntos que consiguieron en c/fase
*/
void mostrarEquiposPorFase(Laebb* laebb);

/*PRE: -
  POS: muestra por cada grupo a los equipos ordenados por puntos 
*/
void mostrarGrupos(Laebb* laebb);

/*PRE:  1 <= fase <=3 (ver 'FASES' en 'constantes.h')
  POS: muestra los equipos que llegaron a la 'fase' ordenados por puntos 
*/
void mostrarFaseEliminatoria(Laebb* laebb, int fase);

/*PRE: fase == 4 || fase == 5 (ver 'FASES' en 'constantes.h')
  POS: muestra los equipos que llegaron a la 'fase' ordenados por puntos 
*/
void mostrarFaseFinal(Laebb* laebb, int fase);

/*PRE: -
  POS: muestra un saludo
*/
void despedida();

#endif