#include "gestorArchivo.h"

void procesarEquipos(Laebb* laebb, string ruta_archivo) {
    ifstream archivo(ruta_archivo);
    if(!archivo.is_open()) {
        cout << "ERROR -- en la apertura del archivo" << endl;
    } else {
        laebb->equipos = new Equipo*[laebb->max];
        string linea;
        while (getline(archivo, linea)) {
            procesarLineaEquipos(linea, laebb);
        }
    } 
    archivo.close();
}

void procesarLineaEquipos(string linea, Laebb* laebb) {
    string nombre;
    char grupo;
    size_t i = 0;
    while(linea[i] != ESPACIO) {
        nombre += linea[i];
        i++;
    }
    grupo = linea[i + 1];

    if(tieneGuion(nombre)) quitarGuion(nombre);

    if(nombre == "España") nombre = "Espania";

    Equipo* equipo = generarEquipo(nombre, grupo);

    agregarEquipo(laebb, equipo);
}

void procesarResultados(Laebb* laebb, string ruta_archivo) {
    ifstream archivo(ruta_archivo);
    if(!archivo.is_open()) {
        cout << "ERROR -- en la apertura del archivo" << endl;
    } else {
        string linea;
        int fase = 0;
        while(getline(archivo, linea)) {       

            if(esUnaFase(linea)) fase = obtenerFase(linea);
            else procesarDatosDeFase(laebb, linea, fase);

            while(getline(archivo, linea) && !esUnaFase(linea)){
                procesarDatosDeFase(laebb, linea, fase);
            }
            if(esUnaFase(linea)) fase = obtenerFase(linea);
        }
    } 
    archivo.close();
}

bool esUnaFase(string linea) {
    bool esFase = false;
    for(int i = 0; i < CANT_FASES && !esFase; i++) {
        if(linea == VEC_FASES[i]) esFase = true;
    }
    return esFase;
}

int obtenerFase(string linea) {
    int fase;
    for(fase = 0; fase < CANT_FASES && linea != VEC_FASES[fase]; fase++);
    return fase;
}

void procesarDatosDeFase(Laebb* laebb, string linea, int fase) {
    Marcador marcador;
    size_t i = 0;
    
    marcador.equipo1 = obtenerNombreDeEquipo(linea, i);

    marcador.golesEquipo1 += linea[++i];
    
    if (fase != GRUPOS) marcador.penalesEquipo1 = obtenerPenales(linea, i);
    
    i += 2;
    
    marcador.equipo2 = obtenerNombreDeEquipo(linea, i);
    
    marcador.golesEquipo2 += linea[++i];
    
    if (fase != GRUPOS) marcador.penalesEquipo2 = obtenerPenales(linea, i);

    guardarResultado(laebb, fase, marcador);

}

string obtenerNombreDeEquipo(string linea, size_t &i) {
    string nombre;
    while (linea[i] != COMA) nombre += linea[i++];
    if(nombre == "España") nombre = "Espania";
    return nombre;
}

string obtenerPenales(string linea, size_t &i){
    string penales;
    i++;
    penales += linea[++i];
    if(penales == MENOS) penales += linea[++i];
    return penales;
}


void guardarResultado(Laebb* laebb, int fase, Marcador marcador) {
    
    Equipo* equipo1 = nullptr;
    Equipo* equipo2 = nullptr;
    
    equipo1 = obtenerEquipo(laebb, marcador.equipo1);
    equipo2 = obtenerEquipo(laebb, marcador.equipo2);

    equipo1->faseAlcanzada = fase;
    equipo2->faseAlcanzada = fase;

    if(stoi(marcador.golesEquipo1) > stoi(marcador.golesEquipo2)){
        equipo1->puntosDeFase[fase] += VICTORIA;
        equipo1->puntosTotales += VICTORIA;
    }
    else if(stoi(marcador.golesEquipo1) < stoi(marcador.golesEquipo2)){
        equipo2->puntosDeFase[fase] += VICTORIA;
        equipo1->puntosTotales += VICTORIA;
    }
    else if(fase == GRUPOS) {
        equipo1->puntosDeFase[fase] += EMPATE;
        equipo1->puntosTotales += EMPATE;
        equipo2->puntosDeFase[fase] += EMPATE;
        equipo2->puntosTotales += EMPATE;
    }else if(stoi(marcador.penalesEquipo1) > stoi(marcador.penalesEquipo2)){
        equipo1->puntosDeFase[fase] += VICTORIA_POR_PENAL;
        equipo1->puntosTotales += VICTORIA_POR_PENAL;
        equipo2->puntosDeFase[fase] += DERROTA_POR_PENAL;
        equipo2->puntosTotales += DERROTA_POR_PENAL;
    }else {
        equipo1->puntosDeFase[fase] += DERROTA_POR_PENAL;
        equipo1->puntosTotales += DERROTA_POR_PENAL;
        equipo2->puntosDeFase[fase] += VICTORIA_POR_PENAL;
        equipo2->puntosTotales += VICTORIA_POR_PENAL;
    }
}