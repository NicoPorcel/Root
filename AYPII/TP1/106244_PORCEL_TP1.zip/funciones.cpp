#include "funciones.h"

/*
EN ESTE ARCHIVO HAGO USO DE 'PAUSAR' Y 'LIMPIAR' LA CONSOLA
EN MI CASO PROGRAMO EN WINDOWS Y ME FUNCIONA.
DEJE COMENTADO EN ESTE ARCHIVO CADA VEZ QUE LLAMO A ESTAS FUNCIONES
DE PAUSAR Y/O LIMPIAR LA CONSOLA PARA QUE PUEDAS COMENTARLAS SIMPLEMENTE
ASI EL PROGRAMA CORRE SIN PROBLEMAS EN CUALQUIER OTRO SISTEMA OP. COMO LINUX.
*/

void menu(Laebb* laebb) {
    string opcion;
    saludar();
    do {
        mostrarMenu();
        cin >> opcion;
        while(!opcionValida(opcion)) {
            cout << "ERROR! - OPCION NO VALIDA." << endl;
            pausarConsola();
            mostrarMenu();
            cin >> opcion;
        }
        
        // -- LIMPIO CONSOLA --
        limpiarConsola();
        
        switch (stoi(opcion)) {
            case LISTAR_EQUIPOS :
                listarEquipos(laebb);
                break;
            case MOSTRAR_PODIO :
                mostrarPodio(laebb);
                break;
            case BUSCAR_POR_NOMBRE :
                buscarEquipoPorNombre(laebb);
                break;
            case MOSTRAR_POR_FASES :
                mostrarEquiposPorFase(laebb);
                break;
        }
        
        // -- PAUSO Y LIMPIO CONSOLA --
        pausarLimpiar();
    
    } while (stoi(opcion) != SALIR);

    despedida();
    
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    liberarMemoria(laebb);
}

void saludar() {
    cout << "--------------------------------------" << endl;
    cout << "------------ BIENVENIDO/A ------------" << endl;   
    cout << "--------------------------------------" << endl;
}

void mostrarMenu() {
    limpiarConsola();
    cout << "------------------ MENU ------------------" << endl;
    cout << "1 - LISTAR EQUIPOS" << endl;
    cout << "2 - MOSTRAR PODIO" << endl;
    cout << "3 - BUSCAR EQUIPO POR NOMBRE" << endl;
    cout << "4 - MOSTRAR EQUIPOS POR FASE" << endl;
    cout << "5 - SALIR" << endl;
    cout << "-------------------------------------" << endl;
    cout << "Ingresa la opcion -> ";
}

bool opcionValida(string opcion) {
    bool valida = false;
    for(size_t i = 0; i < CANT_OPCIONES && !valida; i++){
        if(opcion == VEC_MENU[i]) valida = true;
    }
    return valida;
}

void listarEquipos(Laebb* laebb) {
    for(size_t i = 0; i < laebb->tamanio; i++) {
        cout << "- Equipo : " << laebb->equipos[i]->nombre << endl;
        cout << "  Grupo : " << laebb->equipos[i]->grupo << endl;
        cout << "--------------------------------------" << endl;
    }
}

void mostrarPodio(Laebb* laebb) {
    Equipo podio[TAMANIO_PODIO];

    for(size_t i = 0; i < laebb->tamanio; i++) {
        if(laebb->equipos[i]->faseAlcanzada == FINAL){
            if (laebb->equipos[i]->puntosDeFase[FINAL] > 1) podio[PRIMERO] = *laebb->equipos[i];
            else podio[SEGUNDO] = *laebb->equipos[i];
        } 
        else if(laebb->equipos[i]->faseAlcanzada == TERCER_PUESTO && laebb->equipos[i]->puntosDeFase[TERCER_PUESTO] > 1) {
            podio[TERCERO] = *laebb->equipos[i];
        }
    }

    cout << "--------------------------------------" << endl;
    cout << "1ro - " << podio[PRIMERO].nombre << " - puntos totales: " << podio[PRIMERO].puntosTotales << endl << endl;
    cout << "2do - " << podio[SEGUNDO].nombre << " - puntos totales: " << podio[SEGUNDO].puntosTotales << endl << endl;
    cout << "3ro - " << podio[TERCERO].nombre << " - puntos totales: " << podio[TERCERO].puntosTotales << endl;
    cout << "--------------------------------------" << endl;

}

void buscarEquipoPorNombre(Laebb* laebb) {
    Equipo* equipo = nullptr;
    string nombre;

    cout << "--------------------------------------" << endl;
    cout << "Equipos con 'enie' escribirlo sin ella" << endl;
    cout << "Ej: Espania" << endl;
    cout << "--------------------------------------" << endl;
        
    cout << "Ingrese el nombre del Equipo -> ";
    fflush(stdin);
    getline(cin, nombre);

    equipo = obtenerEquipo(laebb, nombre);
    
    // -- LIMPIO CONSOLA --
    limpiarConsola();

    if(equipo != nullptr) {
        cout << "--------------------------------------" << endl;
        cout << "Nombre : " << equipo->nombre << endl;
        cout << "Grupo : " << equipo->grupo << endl;
        cout << "Fase Alcanzada : " << VEC_FASES[equipo->faseAlcanzada] << endl;
        if(equipo->faseAlcanzada == FINAL) {
            if(equipo->puntosDeFase[FINAL] > 1) cout << "Titulo : CAMPEON" << endl;
            else cout << "Titulo : SUBCAMPEON" << endl;
        }else if(equipo->faseAlcanzada == TERCER_PUESTO){
            if(equipo->puntosDeFase[TERCER_PUESTO] > 1) cout << "Titulo : TERCER PUESTO" << endl;
            else cout << "Titulo : CUARTO PUESTO" << endl;
        }
        cout << "--------------------------------------" << endl;
    }
    else cout << "No se encontro el Equipo." << endl;

}

void mostrarEquiposPorFase(Laebb* laebb) {
    
    mostrarGrupos(laebb);
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    mostrarFaseEliminatoria(laebb, OCTAVOS);
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    mostrarFaseEliminatoria(laebb, CUARTOS);
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    mostrarFaseEliminatoria(laebb, SEMIS);
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    mostrarFaseFinal(laebb, TERCER_PUESTO);
    // -- PAUSO Y LIMPIO CONSOLA --
    pausarLimpiar();

    mostrarFaseFinal(laebb, FINAL);
}

void mostrarGrupos(Laebb* laebb) {
    cout << "-------- FASE DE GRUPOS --------" << endl << endl;
    char grupo;
    ordenarPorPuntosDeFase(laebb, GRUPOS);
    ordenarPorGrupos(laebb);
    for(size_t i = 0; i < laebb->tamanio; i++) {
        grupo = laebb->equipos[i]->grupo;
        cout << "--------- Grupo " << grupo << " ---------" << endl;
        while(i < laebb->tamanio && laebb->equipos[i]->grupo == grupo){
            cout << laebb->equipos[i]->nombre << " - " << laebb->equipos[i]->puntosDeFase[GRUPOS] << " pts." << endl;       
            i++;
        }
        i--;
    }  
}

void mostrarFaseEliminatoria(Laebb* laebb, int fase) {
    cout << "------- " << VEC_FASES[fase] << " -------" << endl;
    ordenarPorPuntosDeFase(laebb, fase);
    for(size_t i = 0; i < laebb->tamanio; i++) {
        if(laebb->equipos[i]->faseAlcanzada >= fase)
            cout << laebb->equipos[i]->nombre << " - " << laebb->equipos[i]->puntosDeFase[fase] << " pts." << endl;
    }
}

void mostrarFaseFinal(Laebb* laebb, int fase) {
    cout << "------- " << VEC_FASES[fase] << " -------" << endl;
    ordenarPorPuntosDeFase(laebb, fase);
    for(size_t i = 0; i < laebb->tamanio; i++) {
        if(laebb->equipos[i]->faseAlcanzada == fase)
            cout << laebb->equipos[i]->nombre << " - " << laebb->equipos[i]->puntosDeFase[fase] << " pts." << endl;
    }
}

void despedida() {
    cout << "--------------------------------------" << endl;
    cout << "-------- HASTA LUEGO CAMPEON/A -------" << endl;   
    cout << "--------------------------------------" << endl;
}