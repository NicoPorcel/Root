#include "Laebb.h"

Equipo* generarEquipo(string nombre, char grupo) {
    Equipo* equipo = nullptr;
    equipo = new Equipo;
    equipo->nombre = nombre;
    equipo->grupo = grupo;
    return equipo;
}

void agregarEquipo(Laebb* laebb, Equipo* equipo) {
    if(laebb->tamanio == laebb->max) pedirMemoria(laebb);

    laebb->equipos[laebb->tamanio] = equipo;
    laebb->tamanio++;

    size_t pos = laebb->tamanio - 1;

    while(pos > 0) {
        if(esMayor(laebb->equipos[pos - 1]->nombre, laebb->equipos[pos]->nombre)) {
            Equipo equipoAux;
            equipoAux = *laebb->equipos[pos];
            *laebb->equipos[pos] = *laebb->equipos[pos - 1];
            *laebb->equipos[pos - 1] = equipoAux;
        }
        pos = pos - 1;
    }
}

bool esMayor(string cadena1, string cadena2) {
    bool esMayor = false;
    bool esMenor = false;
    
    int i = 0;
    while(cadena1[i] && i < cadena2[i] && !esMayor && !esMenor) {
        if(cadena1[i] > cadena2[i]) esMayor = true;
        else if(cadena1[i] < cadena2[i]) esMenor = true;
        i++;
    }

    return esMayor;
}

void pedirMemoria(Laebb* laebb) {
    Equipo** vecEquiposAux = nullptr;
    vecEquiposAux = new Equipo*[laebb->tamanio + 1];
    
    for(size_t i = 0; i < laebb->tamanio; i++) {
        vecEquiposAux[i] = laebb->equipos[i];
    }
    
    if(laebb->tamanio > 0) delete[] laebb->equipos;
    laebb->equipos = vecEquiposAux;
    laebb->max++;
}

Equipo* obtenerEquipo(Laebb* laebb, string nombre) {
    Equipo* equipo = nullptr;

    for (size_t i = 0; i < laebb->tamanio; i++) {
        if(laebb->equipos[i]->nombre == nombre) equipo = laebb->equipos[i];
    }

    return equipo;
}

void ordenarPorPuntosDeFase(Laebb* laebb, int fase) {
    size_t i, j;
    Equipo equipoAux;
    for (i = 0; i < laebb->tamanio - 1; i++)
        for (j = 0; j < laebb->tamanio - i - 1; j++)
            if (laebb->equipos[j]->puntosDeFase[fase] < laebb->equipos[j + 1]->puntosDeFase[fase]){
                equipoAux = *laebb->equipos[j];
                *laebb->equipos[j] = *laebb->equipos[j + 1];
                *laebb->equipos[j + 1] = equipoAux;
            }    
}

void ordenarPorGrupos(Laebb* laebb) {
    size_t i, j;
    Equipo equipoAux;
    for (i = 0; i < laebb->tamanio - 1; i++)
        for (j = 0; j < laebb->tamanio - i - 1; j++)
            if (laebb->equipos[j]->grupo > laebb->equipos[j + 1]->grupo){
                equipoAux = *laebb->equipos[j];
                *laebb->equipos[j] = *laebb->equipos[j + 1];
                *laebb->equipos[j + 1] = equipoAux;
            }
}

void liberarMemoria(Laebb* laebb) {
    for(size_t i = 0; i < laebb->tamanio; i++){
        delete laebb->equipos[i];
    }     
    if(laebb->equipos) delete[] laebb->equipos;
    delete laebb;
}