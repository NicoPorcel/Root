void contar_frutas(){}
void buscar_frutas(){}
void ordenar_frutas(){}
