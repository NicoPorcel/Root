#ifndef FRUTAS_H
#define FRUTAS_H

//aca definir struct

//pre:
//post:
void contar_frutas();

//pre:
//post:
void buscar_frutas();

//pre:
//post:
void ordenar_frutas();

#endif //FRUTAS_H
